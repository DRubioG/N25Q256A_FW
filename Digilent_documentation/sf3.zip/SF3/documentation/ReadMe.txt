reference materials can be found at the Digilent resource center

https://reference.digilentinc.com/reference/pmod/pmodsf3/start